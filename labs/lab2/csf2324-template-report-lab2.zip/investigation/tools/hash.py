import hashlib

def hash_18_times(seed):
    for _ in range(18):
        seed = hashlib.sha256(str(seed).encode('utf-8')).hexdigest()
    return seed

def get_hash(count, seed, timestamps):
    if count == 0:
        seed = "WolfgangPuckCulinary$"
    count += 1
    for timestamp in timestamps:
        pw = hashlib.sha256((seed + timestamp).encode('utf-8')).hexdigest()
        print(pw)
        seed = hashlib.sha256(seed.encode('utf-8')).hexdigest()

timestamps = [
    "1696071001",
    "1696071301",
    "1696071601",
    "1696071901",
    "1696072201",
    "1696072501",
    "1696072801",
    "1696073101",
    "1696073401",
    "1696073701",
    "1696074001",
    "1696074301",
    "1696074601",
    "1696075201",
    "1696075801",
    "1696076401"
]

get_hash(0, "", timestamps)

#seed = "WolfgangPuckCulinary$"
#result = hash_18_times(seed)
#print(result)
